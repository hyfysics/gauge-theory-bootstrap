Snapshot for arXiv:2505.19332
